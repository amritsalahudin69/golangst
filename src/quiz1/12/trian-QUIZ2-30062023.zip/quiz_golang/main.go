package main

import (
	"encoding/json"
	"fmt"
)

type ImageArticle struct {
	Image          string `json:"image"`
	ImageDesktop   string `json:"imageDesktop"`
	ImageHighlight string `json:"imageHighlight"`
}

type Author struct {
	FullName       string `json:"fullName"`
	ProfilePicture string `json:"profilePicture"`
	UserName       string `json:"userName"`
}

type Meta struct {
	Title        string `json:"title"`
	Keyword      string `json:"keyword"`
	Description  string `json:"descrription"`
	CanonicalURL string `json:"canonicalURL"`
}

type Translation struct {
	Title         string `json:"title"`
	Slug          string `json:"slug"`
	Excerpt       string `json:"excerpt"`
	Content       string `json:"content"`
	Locale        string `json:"locale"`
	UrlShare      string `json:"urlShare"`
	Lang          string `json:"lang"`
	ArticleId     int    `json:"articleId"`
	RatingComment string `json:"ratingComment"`
}

type Article struct {
	ArticleID    int          `json:"articleId"`
	ImageArticle ImageArticle `json:"imageArticle"`
	Author       Author       `json:"author"`
	Translation  Translation  `json:"translation"`
	Meta         Meta         `json:"meta"`
}

func (a Article) GetResponse() ([]byte, error) {
	response, err := json.Unmarshal(a)
	if err != nil {
		return nil, err
	}
	return response, nil
}

func main() {
	article := Article{
		ArticleID: 23928,
		ImageArticle: ImageArticle{
			Image:          "https://api.duniagames.co.id/api/content/upload/file/9874800061688113932.jpg",
			ImageDesktop:   "https://api.duniagames.co.id/api/content/upload/file/9074251731688113932.jpg",
			ImageHighlight: "https://api.duniagames.co.id/api/content/upload/file/9842838701688113932.jpg",
		},
		Author: Author{
			FullName:       "haris13",
			ProfilePicture: "https://api.duniagames.co.id/api/user/upload/image/223816331649748676.jpg",
			UserName:       "Haris Firmansyah",
		},
		Translation: Translation{
			Title:         "Benedetta Mobile Legends (ML) Hero: Skill, Build dan Kelebihan",
			Slug:          "hero-benedetta-mobile-legends",
			Excerpt:       "Penasaran ingin tahu tentang hero Benedetta Mobile Legends (ML)? Lihat artikel Dunia Games dan pelajari tentang skills, build, dan kelebihannya.",
			Content:       `<p><span style="font-weight: 400;">Benedetta adalah seorang hero</span><em><span style="font-weight: 400;"> Assassin</span></em><span style="font-weight: 400;"> di </span><em><span style="font-weight: 400;">Mobile Legends</span></em><span style="font-weight: 400;"> dengan kemampuan yang menakutkan di </span><em><span style="font-weight: 400;">Land of Dawn</span></em><span style="font-weight: 400;">. Benedetta mampu menghasilkan </span><em><span style="font-weight: 400;">burst damage</span></em><span style="font-weight: 400;"> yang tinggi dengan area yang besar, membuat musuh merasa kesulitan saat berhadapan dengan Benedetta ketika </span><em><span style="font-weight: 400;">team fight</span></em><span style="font-weight: 400;">. Penasaran ingin tahu tentang hero Benedetta Mobile Legends (ML)? Lihat artikel Dunia Games dan pelajari tentang skills, build, dan kelebihannya.</span></p>`,
			Locale:        "id",
			UrlShare:      "https: duniagames.co.id discover article hero-benedetta-mobile-legends",
			Lang:          "id",
			ArticleId:     23928,
			RatingComment: "null",
		},
		Meta: Meta{
			Title:        "Benedetta Mobile Legends (ML) Hero: Skill, Build dan Kelebihan",
			Keyword:      "Benedetta",
			Description:  "Penasaran ingin tahu tentang hero Benedetta Mobile Legends (ML)? Lihat artikel Dunia Games dan pelajari tentang skills, build, dan kelebihannya.",
			CanonicalURL: "null",
		},
	}

	response, err := article.GetResponse()
	if err != nil {
		fmt.Println("Error:", err)
		return
	}

	fmt.Println(string(response))
}
